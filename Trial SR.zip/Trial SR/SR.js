var TARGET_SIZE = 16;
var startTime, intervalID;
var rescue, target, direction, radarRange, context;

function start()
{
	var canvas = document.getElementById("searchArea");
do	{
	canvas.height = window.prompt("Search area height (must be less than "+window.innerWidth+"):", canvas.height);
	console.log(canvas.height);
	if (canvas.height<=0) {
		alert("Please Enter a Number or a Number greater than 0");
	}
	if (canvas.height > window.innerWidth) {
		alert("Please Enter a Number less than" + window.innerWidth);
	}
} while((canvas.height <= 0) || (canvas.height > window.innerWidth))
console.log(window.innerWidth)

	rescue = {x: canvas.width / 2, y: canvas.width / 2};
	target = {x : canvas.width * Math.random(), y : canvas.height * Math.random()};

	direction = {dx: 1, dy: 1};
	radarRange = document.getElementById("radar").value;

	context = canvas.getContext('2d');
	startTime = (new Date()).getTime();
	intervalID = setInterval(simulate, 3);
}

function simulate()
{
  clear();
	drawTarget();
	drawRescue();
	updateProgress();
	if (found())
	{
		clearInterval(intervalID);
	}
	else
	{
		if (xBoundary()) direction.dx = -direction.dx;
		if (yBoundary()) direction.dy = -direction.dy;
		rescue.x += direction.dx;
		rescue.y += direction.dy;
	}
  toTarget();
}

function clear()
{
	context.clearRect(0, 0, context.canvas.width, context.canvas.height);
}

function drawTarget()
{
	var shipSize = 20;
	context.beginPath();
	context.lineWidth = "4";
	context.strokeStyle = "red";
	context.line
	context.arc(target.x, target.y, shipSize ,Math.PI, Math.PI*2,true);
	context.stroke();
	context.moveTo(target.x - shipSize, target.y);
	context.lineTo(target.x + shipSize, target.y);
	context.stroke();
	context.moveTo(target.x , target.y - shipSize);
	context.lineTo(target.x , target.y);
	context.stroke();
	context.rect(target.x, target.y - 2*shipSize, shipSize, shipSize);
	context.stroke();
}

function drawRescue()
{
	context.beginPath();
	context.fillStyle = "#0000ff";
	context.arc(rescue.x, rescue.y, radarRange, 0, Math.PI * 2, true);
	context.closePath();
	context.fill();
}

function xBoundary()
{
	return ((rescue.x >= context.canvas.width - radarRange)||(rescue.x < 0 + radarRange));
}

function yBoundary()
{
	return ((rescue.y >= context.canvas.height - radarRange)||(rescue.y<0 + radarRange));
}

function updateProgress()
{
	var elapsed = document.getElementById("elapsed");
	elapsed.innerHTML = Math.floor(((new Date()).getTime() - startTime) / 1000);
  var distance = document.getElementById("distance");
  distance.innerHTML = Math.floor(toTarget());
}

function toTarget()
{
	return Math.sqrt(Math.pow(Math.abs(target.x - rescue.x), 2) + Math.pow(Math.abs(target.y - rescue.y), 2));

}

function found()
{
	if (toTarget() < radarRange) {
		return true;
	} else {
		return false;
	}
}

function changeCanvas() {
	var height = document.getElementById("canvasHeight");
	var canvas = document.getElementById("searchArea");
	canvas.setAttribute("height",height.value);

}

function alternate() {
	var javaScript = document.getElementById("js");
	javaScript.setAttribute("src","SR2.js");
	clear();
}
