//main
function go() {
  access(url, "update collection set quantity = 2", null);
  access(url, "alter table collection add column source", null);
  var identity = 101;
  var a = [
  "https://www.youtube.com/embed/zcBjfBpgH8Q","https://www.youtube.com/embed/FEPFH-gz3wE",
  "https://www.youtube.com/embed/_lNP-x94-SE","https://www.youtube.com/embed/8BM9TNa-FV4",
  "https://www.youtube.com/embed/fZ_YAK0NSX0","https://www.youtube.com/embed/KDz5wVc-4QI",
  "https://www.youtube.com/embed/9x-DQBuervc","https://www.youtube.com/embed/pAgnJDJN4VA",
  "https://www.youtube.com/embed/PdLIerfXuZ4","https://www.youtube.com/embed/PdLIerfXuZ4",
  "https://www.youtube.com/embed/zucBfXpCA6s","https://www.youtube.com/embed/0UhnfWzOCMo",
  "https://www.youtube.com/embed/QL14TuFKTwU","https://www.youtube.com/embed/zkP4H2WdSiY",
  "https://www.youtube.com/embed/9cNQFB0TDfY","https://www.youtube.com/embed/ryQ2WjmcYWI",
  "https://www.youtube.com/embed/JDZ_DlNfsWk","https://www.youtube.com/embed/QHF6pu-3GXk",
  "https://www.youtube.com/embed/PdLIerfXuZ4","https://www.youtube.com/embed/PdLIerfXuZ4"
  ]
  for(var i = 0; i<a.length; i++) {
      access(url, "update collection set source ='"+a[i]+"' where id ="+identity, null);
      identity++;
  }
  access(url, "select distinct artist from collection order by artist;", artistCallback);
}


//callback
function albums(json) {
  var o = document.getElementById("output");
  for(var e=0;e<json.length;e++) {
    o.innerHTML += json[e].album + "<br>";
  }
}

function artistCallback(jsontext){
 var json = JSON.parse(jsontext.responseText);
 document.getElementById('output').appendChild(buildArtistPullDown(json));
 access(url, "select distinct year from collection order by year", yearCallback);
}
function yearCallback(jsontext){
  var json = JSON.parse(jsontext.responseText)
 document.getElementById('output').appendChild(buildYearPullDown(json));
 var s = document.createElement("button");
 s.setAttribute('id', 'find');
 s.setAttribute('onclick','find()');
 s.innerHTML = "Find";
 document.getElementById('output').appendChild(s);
}
function selectCalback(jsontext)
{
  var json = JSON.parse(jsontext.responseText)
  var result = document.getElementById('result');
  while (result.firstChild)
  {
    result.removeChild(result.firstChild);
  }
  for(var i=0;i<json.length;i++)
  {
    var br = document.createElement("br");
    result.appendChild(br);
    var q = document.createElement("div");
    result.appendChild(q);

    var img = document.createElement("img");
    img.setAttribute("width", '100px');
    img.setAttribute("height", '100px');
    img.setAttribute("src", json[i].cover);
    q.appendChild(img);

    var album = document.createElement("span");
    album.innerHTML = "<br>Album: "+json[i].album+" <br>Price: $"+json[i].price +"<br>";
    q.appendChild(album);
    var quantity = document.createElement("span");
    quantity.setAttribute("id","quantity"+json[i].id);
    quantity.innerHTML = "Quantity: "+json[i].quantity + "<br>";
    q.appendChild(quantity);

    var s = document.createElement("button");
    s.setAttribute('id', 'Purchase');
    s.setAttribute('onclick','purchase('+json[i].id+')');
    s.innerHTML = "Purchase";
    q.appendChild(s);

    var musicdiv = document.createElement("div");
    quantity.innerHTML = "Quantity: "+(json[i].quantity-1)+"<br>"
    music = document.createElement("iframe")
    music.style.height = "150px";
    music.style.width = "320px";
    music.src= json[i].source;
    musicdiv.appendChild(music);
    q.appendChild(musicdiv);
  }
}
function purchaseCallback(jsontext)
{
  var json = JSON.parse(jsontext.responseText);
  if(json[0].quantity<1)
  {
    alert("Sorry, it is out of stock");
  }
  else
  {
      alert("It will charge your $"+json[0].price);
      //alert("update collection set quantity="+(json[0].quantity-1)+" where id="+json[0].id);
      access(url, "update collection set quantity="+(json[0].quantity-1)+" where id="+json[0].id, buyCallBack);
      var quantity = document.getElementById("quantity"+json[0].id);
  }
}

function buyCallBack(jsontext){

  alert("Success");
}
function purchase(id) {
 //alert(id);
 access(url,"select price,album,quantity,id from collection where id=" +
id, purchaseCallback);
}
//DOM
function find()
{
  var artist = document.getElementById("artist");
  var year = document.getElementById("year");
  if(artist.selectedIndex>0 && year.selectedIndex>0)
  {
    var a = artist.options[artist.selectedIndex].value;
    var b = year.options[year.selectedIndex].value;
    access(url,'select * from collection where artist="'+a+'" and year="'+b+'"', selectCalback);
  }else if(artist.selectedIndex>0)
  {
    var a = artist.options[artist.selectedIndex].value;
    access(url,'select * from collection where artist="'+a+'"', selectCalback);
  }
  else if(year.selectedIndex>0)
  {
    var b = year.options[year.selectedIndex].value;
    access(url,'select * from collection where year="'+b+'"', selectCalback);
  }
  else
  {
    access(url,"select * from collection", selectCalback);
  }

}
function buildArtistPullDown(json)
{
 var s = document.createElement("select");
 s.setAttribute('id', 'artist');

 var h = document.createElement("option");
 h.innerHTML = "<b>Artists</b>";
 s.appendChild(h);
 for(var i=0;i<json.length;i++) {
 var v = json[i].artist;
 var q = document.createElement("option");
 q.setAttribute("id",v);
 q.innerHTML = v;
 s.appendChild(q);
 }
 return s;
}

function buildYearPullDown(json)
{
 var s = document.createElement("select");
 s.setAttribute('id', 'year');

 var h = document.createElement("option");
 h.innerHTML = "<b>Year</b>";
 s.appendChild(h);
 for(var i=0;i<json.length;i++) {
 var v = json[i].year;
 var q = document.createElement("option");
 q.setAttribute("id",v);
 q.innerHTML = v;
 s.appendChild(q);
 }
 return s;
}

//ajax
var url = "http://127.0.0.1:8000/sql?query= "


function access(url, query, callback) {
  new Ajax.Request(
     url + query,
    {
      asynchronous: true,
      contentType:'application/json',
      method:'get',
      onSuccess: callback
    }
  );
}


onload=go;
