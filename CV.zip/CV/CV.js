
function start () {
  var now = document.getElementById("now");
  now.innerHTML = "Last Updated " + Date();
  var that =document.createElement('p');
  that.id="things";
  now.appendChild(that);
}

var n = 1;
function swap() {
  var picture = document.getElementById("picture");
  var oddeven = Math.pow(-1,n);
  if (oddeven === -1) {
    picture.src = "profilepic1.jpg";
  } else {
    picture.src = "profilepic2.jpg";
  }
  n = n + 1;
}
