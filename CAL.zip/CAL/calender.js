function updatePage() {
  var d = new Date();
  var e = document.getElementById("info");

  var d = new Date();

  var day = d.getDay();
  var hour = d.getHours();
  var minutes = d.getMinutes();

  if (minutes < 30) {
    hour = hour-1;
  }

  var block = "time" + day + ":" + hour;
  e.innerHTML = "My Schedule"
  var c = document.getElementById(block);

  if((lastTime != null) && (lastTime != c)) {
    lastTime.style.background = 'white';
  }

  if (c != null) {
    c.style.background = 'red';
  }

  lastTime = c;
}


function startUpdate() {
  updatePage();
  window.setInterval(updatePage, 10*1000);
  setCourse(eecs1012Time);
  setCourse(eecs1012LabTime);
}

var lastTime = null;
window.onload = startUpdate;

var eecs1012Time = ["time1:15","time1:16","time3:15","time3:16","EECS1012","https://moodle.yorku.ca/moodle/course/view.php?id=88703"];
var eecs1012LabTime = ["time2:15","time2:16","time2:17","time4:15","time4:16","time4:17","EECS1012 Lab","https://moodle.yorku.ca/moodle/course/view.php?id=88703"];
function setCourse(params) {
  var i = 0;
  var n = params.length - 1;

  while (i <= n - 2){
    var time = params[i];
    var z = document.getElementById(time);

    if (z != null) {
      z.innerHTML= "<a href="+params[n]+" target = "+"_blank"+">"+params[n-1]+"</a>";
    }
    i=i+1;
  }
}
