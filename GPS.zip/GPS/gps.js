/* jslint browser:true */

var id = null;
var firstTime = -1;
//first building is the Tiat Mckenzie Centre
var latitudeCalabrationFirstBuilding = 43.775698;
var longitudeCalabrationFirstBuilding = -79.512874;
//second building is Seneca building
var latitudeCalabrationSecondBuilding = 43.771453;
var longitudeCalabrationSecondBuilding = -79.496673;
var xCalabrationMapFirstBuilding = 0;
var yCalabrationMapFirstBuilding = 0;
var xCalabrationMapSecondBuilding = 540;
var yCalabrationMapSecondBuilding = 370;
var loc1 = {lat : 43.772413, lon : -79.505664, desc : "Scott Library"};
var loc2 = {lat : 43.772809, lon : -79.503196, desc : "Vari Hall"};
var loc3 = {lat : 43.771530, lon : -79.49913, desc : "Seneca"};
var caches = new Array();
caches[0] = loc1;
caches[1] = loc2;
caches[2] = loc3;
var currentCache = -1;

function togglegps() {
    var button = document.getElementById("togglegps");
    if (navigator.geolocation) {
        if (id === null) {
            id = navigator.geolocation.watchPosition(showPosition);
            button.innerHTML = "STOP GPS";
            firstTime = -1;
        } else {
            navigator.geolocation.clearWatch(id);
            id = null;
            button.innerHTML = "START GPS";
        }
    } else {
        alert("NO GPS AVAILABLE");
    }
    document.getElementById("arrow").src = "me.gif";
}

function handleError(error) {
    var errorstr = "Really unknown error";
    switch (error.code) {
    case error.PERMISSION_DENIED:
        errorstr = "Permission deined";
        break;
    case error.POSITION_UNAVAILABLE:
        errorstr = "Permission unavailable";
        break;
    case error.TIMEOUT:
        errorstr = "Timeout";
        break;
    case error.UNKNOWN_ERROR:
        error = "Unknown error";
        break;
    }
//    alert("GPS error " + error);
}

var meLon;
var meLat;
var targetLon;
var targetLat;
function showPosition(position) {
    var latitude = document.getElementById("latitude");
    var longitude = document.getElementById("longitude");
    var now = document.getElementById("now");
    var debug = document.getElementById("debug");
    var direction = document.getElementById("direction");

    var lat = latitude.innerHTML = position.coords.latitude;
    var lon = longitude.innerHTML = position.coords.longitude;
    meLon = position.coords.longitude;
    meLat = position.coords.latitude;
    var y = interpolate(latitudeCalabrationSecondBuilding, latitudeCalabrationFirstBuilding, yCalabrationMapSecondBuilding, yCalabrationMapFirstBuilding, lat);
    var x = interpolate(longitudeCalabrationSecondBuilding, longitudeCalabrationFirstBuilding, xCalabrationMapSecondBuilding, xCalabrationMapFirstBuilding, lon);
    if (firstTime < 0) {
      firstTime = position.timestamp;
    }
    debug.innerHTML = "x:" + x + " y:" + y;
    now.innerHTML = position.timestamp - firstTime;
    var me = document.getElementById("me");
    me.style.top = y + "px";
    me.style.left = x + "px";
    var arrow = document.getElementById("arrow");
    me.style.transform = 'rotate('+position.coords.heading+'deg)';
// haversine formula source https://stackoverflow.com/questions/14560999/using-the-haversine-formula-in-javascript
    var R = 6371e3; // metres
  var phi1 = meLat*(Math.PI/180);
  var phi2 = targetLat*(Math.PI/180);
  var deltaPhi = (targetLat-meLat)*(Math.PI/180);
  var deltaLambda = (targetLon-meLon)*(Math.PI/180);

  var a = Math.sin(deltaPhi/2) * Math.sin(deltaPhi/2) +
          Math.cos(phi1) * Math.cos(phi2) *
          Math.sin(deltaLambda/2) * Math.sin(deltaLambda/2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  var d = (R * c).toFixed(2);
direction.innerHTML = "direction:"+position.coords.heading+"<br> accuracy:"+position.coords.accuracy+"<br> altitude:"+position.coords.altitude+ "<br>Distance to Target: "+d+" meters";

}

function interpolate(gps_1, gps_2, u_1, u_2, gps_i) {
  return u_1 + (u_2 - u_1)*(gps_i - gps_1)/(gps_2 - gps_1);
}

function updateCache() {
  currentCache++;
  currentCache = currentCache%3;

  showCache();
  var target = document.getElementById("pokemon");
  if (currentCache==0) {
    target.src = "pikachu.gif";
  } else if (currentCache==1) {
    target.src = "turtle.gif";
  } else if (currentCache==2) {
    target.src = "listle.gif";
  }
}

function showCache() {
  var b = interpolate(latitudeCalabrationSecondBuilding, latitudeCalabrationFirstBuilding, yCalabrationMapSecondBuilding, yCalabrationMapFirstBuilding, caches[currentCache].lat);
  var a = interpolate(longitudeCalabrationSecondBuilding, longitudeCalabrationFirstBuilding, xCalabrationMapSecondBuilding, xCalabrationMapFirstBuilding, caches[currentCache].lon);
  var target = document.getElementById("target");
  var go = document.getElementById("return");
  target.style.top = b + "px";
  target.style.left = a + "px";
  targetLat = caches[currentCache].lat;
  targetLon = caches[currentCache].lon;


go.innerHTML = "(a, b) (" + a + "," + b +")";

}
