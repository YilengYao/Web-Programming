function drawCanvas() {
  alert("dravCanvas called");
  var id = document.getElementById("mycanvas");
  var cx = id.getContext("2d");
  cx.beginPath;
  cx.moveTo(0,0);
  cx.lineTo(639, 479);
  cx.closePath();
  cx.stroke();
}

window.onload = drawCanvas;
